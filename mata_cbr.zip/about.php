<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">About RSKM Padang Eye Center</h2>
<div class="art-postcontent">
  <h2>Profil Rumah Sakit :</h2>
  <p>RS Mata Padang Eye Center yaitu salah satu Rumah Sakit milik Swasta/Lainnya Kota Padang yang bermodel RS Mata, dinaungi oleh  PT. Muda Medika Mand  Perusahaan dan tergolong kedalam Rumah Sakit Kelas <strong>C</strong>. Rumah Sakit ini telah terdaftar mulai  09/05/2012 dengan Nomor Surat Izin  1625/Regdit-P.SDM/DKK/X/2014 dan Tanggal Surat Izin  10/09/2014 dari  Dinas Kesehatan Kota Padang dengan Sifat  Tetap, dan berlaku sampai . Sehabis mengadakan Metode AKREDITASI Rumah sakit Seluruh Indonesia dengan proses akhirnya diberikan status  Bersyarat Akreditasi Rumah Sakit.</p>
  <p>&nbsp;</p>
<p></p>
<ul>
  <li>
    <p><strong>Jalan</strong>: Jl. Pemuda No.53, Olo, Padang Barat, Kota Padang, Sumatera Barat, Indonesia</p>
  </li>
  <li><p><strong>Phone </strong>: 08116619987</li></p>
  <li>
    <p><strong>Email</strong>: <a href="http://padangeyecenter.com/hal-profil-padang-eye-center.html#">rs_pec@yahoo.com</a></p>
  </li>
</ul>
<p>&nbsp;</p>
<div class="CSSTableGenerator">

</div>
</div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
    </div>
</div>