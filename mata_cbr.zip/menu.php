	<nav class="navbar navbar-expand-lg navbar-light bg-cream">
		<div class="container-fluid">
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav container">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php?top=home.php"><span class="l"></span><span class="r"></span><span class="t">HOME</span></a>
					</li>	
					<li class="nav-item">
						<a class="nav-link" href="index.php?top=pasien_add_fm.php"><span class="l"></span><span class="r"></span><span class="t">PROSES DIAGNOSA</span></a>
					</li>	
					<li class="nav-item">
						<a class="nav-link" href="index.php?top=info-penyakit.php"><span class="l"></span><span class="r"></span><span class="t">INFORMASI</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="index.php?top=about.php"><span class="l"></span><span class="r"></span><span class="t">TENTANG</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="index.php?top=daftar-penyakit.php"><span class="l"></span><span class="r"></span><span class="t">DAFTAR PENYAKIT</span></a>
					</li>		
					<li class="nav-item">
						<a class="nav-link" target="_blank" href="admin/index.php"><span class="l"></span><span class="r"></span><span class="t">LOGIN</span></a>
					</li>	
				</ul>
			</div>
		</div>
	</nav>