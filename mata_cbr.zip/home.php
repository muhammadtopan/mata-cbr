<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h1 class="text-secondary">Selamat Datang di Sistem Pakar Penyakit Mata</h1>
<div class="row">
    <div class="col-sm-4"><img src="images/top-image--salah-didik-anak-bisa-jadi-klepto.jpg" style="image-size: cover"/></div>
    <div class="col-lg-6 alight-middle">
        <strong >Penyakit mata sangat beragam dan tidak semuanya dapat menular. Jika penyakit mata disebabkan virus atau bakteri maka bisa menular, sedangkan jika penyebabnya alergi tidak akan menular. Cara penanganan dan pencegahan macam-macam penyakit mata ini pun berbeda, tergantung penyebabnya. Berikut ini beragam penyakit mata yang perlu Anda ketahui : agar tidak terjadi glaukoma karena kepekaan syaraf pada otot konjungtiva pada mata</strong>
    </div>
</div>
<p>Kasus kebutaan di Indonesia secara keseluruhan tergolong tidak begitu tinggi. Meski begitu, gangguan penglihatan dan kebutaan masih menjadi momok kesehatan serius khususnya pada kelompok lansia. Tingginya angka kebutaan di usia lanjut sebagian besar disebabkan oleh katarak, yang memang dapat berkembang seiring bertambahnya usia. Lantas, apalagi jenis penyakit mata lainnya yang paling umum terjadi di Indonesia?</p>

<p>Penyakit mata sangat beragam dan tidak semuanya dapat menular. Jika penyakit mata disebabkan virus atau bakteri maka bisa menular, sedangkan jika penyebabnya alergi tidak akan menular. Cara penanganan dan pencegahan macam-macam penyakit mata ini pun berbeda, tergantung penyebabnya. Berikut ini beragam penyakit mata yang perlu anda ketahui.</p><br/><br/>
    <div class="row d-flex justify-content-center">
        <a class="btn btn-info rounded-pill text-light text-center col-8 pt-2 pb-2" href="index.php?top=pasien_add_fm.php" class="active">
            <strong>Mulai Diagnosa</strong>
        </a>
    </div>
</div>
</div>
</div>